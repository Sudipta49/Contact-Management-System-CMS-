package com.system.management.contact.exception;

public class InvalidInputException extends AppException{
    public InvalidInputException(String errorType, String errorCode, String message) {
        super(errorType, errorCode, message);
    }
}
