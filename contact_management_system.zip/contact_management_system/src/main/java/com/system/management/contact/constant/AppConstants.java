package com.system.management.contact.constant;

public interface AppConstants {

    public interface FileLocation {

        String PROPERTY_PATH = "classpath:application.properties";
    }


    public interface StatusCodes {
        int SUCCESS = 1;
        int FAILURE = 0;
        int SESSION_EXPIRE = 2;
    }

    public interface ErrorTypes {
        String ENTITY_DOES_NOT_EXISTS = "Entity Doesn't Exists";
        String EXPENSE_NOT_EXISTS = "Expense Doesn't Exists";
        String INVOICE_NOT_EXISTS = "Invoice Doesn't Exists";
//        String ENTITY_DOES_NOT_EXISTS = "Entity Doesn't Exists";

    }

    public interface ErrorCodes {
        String ENTITY_DOES_NOT_EXISTS = "175";

        String EXPENSE_NOT_EXISTS_CODE = "175";

    }

    public interface ErrorMessages {
        String ENTITY_DOES_NOT_EXISTS = "Entity Doesn't Exists";

        String EXPENSE_NOT_EXISTS_MESSAGE = "Expense not exists in Database";

    }

    public interface Commons{

        String PAGE_NUMBER = "page";
        String PAGE_DEFAULT_VALUE = "0";
        String PAGE_LIMIT = "limit";
        String PAGE_LIMIT_VALUE = "10";       
        
    }
}
