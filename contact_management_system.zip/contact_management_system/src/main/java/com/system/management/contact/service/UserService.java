package com.system.management.contact.service;

import com.system.management.contact.request.CreateUserRequest;
import com.system.management.contact.request.EditUserRequest;
import com.system.management.contact.response.EditUserResponse;

public interface UserService {

	Object createUser(CreateUserRequest requestModel);

	EditUserResponse editUser(EditUserRequest requestModel);

	Object viewUserById( Long userId);

	Object viewUserList(String firstName, String lastName, String email);

	Object deleteUser(Long userId);

}