package com.system.management.contact.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "user")

public class UserEntity extends BaseEntity {
	
	private String firstName;
	
	private String lastName;
	
	private String email;
	
	private String phoneNumber;

}
