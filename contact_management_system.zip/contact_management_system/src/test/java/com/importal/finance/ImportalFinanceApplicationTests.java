package com.importal.finance;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImportalFinanceApplicationTests {

	@Test
	void contextLoads() {
	}

}
