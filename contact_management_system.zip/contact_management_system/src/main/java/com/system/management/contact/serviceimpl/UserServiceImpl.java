package com.system.management.contact.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.ObjectUtils;

import com.system.management.contact.constant.AppConstants;
import com.system.management.contact.entity.UserEntity;
import com.system.management.contact.exception.EntityNotFoundExceptions;
import com.system.management.contact.exception.InvalidInputException;
import com.system.management.contact.repository.UserRepository;
import com.system.management.contact.request.CreateUserRequest;
import com.system.management.contact.request.EditUserRequest;
import com.system.management.contact.response.EditUserResponse;
import com.system.management.contact.response.ViewUserResponse;
import com.system.management.contact.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	UserRepository repository;
	
	

	@Override
	public Object createUser(CreateUserRequest requestModel) {

		UserEntity entity = new UserEntity();

		entity.setFirstName(requestModel.getFirstName());
		entity.setLastName(requestModel.getLastName());
		entity.setEmail(requestModel.getEmail());
		entity.setPhoneNumber(requestModel.getPhoneNumber());
		repository.save(entity);
		return "user entity created successfuly";
	}

	@Override
	public EditUserResponse editUser(EditUserRequest requestModel) {

		UserEntity entity = repository.findById(requestModel.getId())
				.orElseThrow(() -> new EntityNotFoundExceptions(AppConstants.ErrorTypes.ENTITY_DOES_NOT_EXISTS,
						AppConstants.ErrorCodes.ENTITY_DOES_NOT_EXISTS,
						AppConstants.ErrorMessages.ENTITY_DOES_NOT_EXISTS));

		entity.setFirstName(requestModel.getFirstName());
		entity.setLastName(requestModel.getLastName());
		entity.setEmail(requestModel.getEmail());
		entity.setPhoneNumber(requestModel.getPhoneNumber());
		repository.save(entity);

		EditUserResponse response = new EditUserResponse();
		response.setId(entity.getId());
		response.setFirstName(entity.getFirstName());
		response.setLastName(entity.getLastName());
		response.setEmail(entity.getEmail());
		response.setPhoneNumber(entity.getPhoneNumber());

		return response;
	}

	@Override
	public Object viewUserById( Long userId) {

		UserEntity entity = repository.findById(userId)
				.orElseThrow(() -> new InvalidInputException(AppConstants.ErrorTypes.ENTITY_DOES_NOT_EXISTS,
						AppConstants.ErrorCodes.ENTITY_DOES_NOT_EXISTS,
						AppConstants.ErrorMessages.ENTITY_DOES_NOT_EXISTS));

		EditUserResponse response = new EditUserResponse();
		response.setId(entity.getId());
		response.setFirstName(entity.getFirstName());
		response.setLastName(entity.getLastName());
		response.setEmail(entity.getEmail());
		response.setPhoneNumber(entity.getPhoneNumber());

		return response;
	}

	@Override
	public Object viewUserList(String firstName, String lastName,
			String email) {

		List<UserEntity> userEntity;

	
			userEntity = repository.findByUsingFilter(firstName, lastName, email);
		

		return userEntity.stream().map(this::viewAllUserResponse);

	}

	ViewUserResponse viewAllUserResponse(UserEntity userEntity) {
		ViewUserResponse viewAllUserResponse = ViewUserResponse.builder().firstName(userEntity.getFirstName()).id(userEntity.getId())
				.lastName(userEntity.getLastName()).email(userEntity.getEmail())
				.phoneNumber(userEntity.getPhoneNumber()).build();

		return viewAllUserResponse;
	}

	@Override
	public Object deleteUser(Long userId) {


		UserEntity entity = repository.findById(userId)
				.orElseThrow(() -> new InvalidInputException(AppConstants.ErrorTypes.ENTITY_DOES_NOT_EXISTS,
						AppConstants.ErrorCodes.ENTITY_DOES_NOT_EXISTS,
						AppConstants.ErrorMessages.ENTITY_DOES_NOT_EXISTS));

		entity.setActive(false);
	
		repository.save(entity);
		return "expense deleted";
		
	}

}