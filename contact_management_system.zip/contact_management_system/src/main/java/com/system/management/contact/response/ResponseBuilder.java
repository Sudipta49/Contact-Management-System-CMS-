package com.system.management.contact.response;
import com.system.management.contact.constant.AppConstants;
import com.system.management.contact.exception.AppException;

public class ResponseBuilder {
public static BaseApiResponse getSuccessResponse(Object responseData) throws AppException {
		
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		//baseApiResponse.setResponseStatus(new ResponseStatus(AppConstants.StatusCodes.SUCCESS));
		baseApiResponse.setStatusCode(AppConstants.StatusCodes.SUCCESS);
		baseApiResponse.setResponseData(responseData);
		baseApiResponse.setResponseStatus(new ResponseStatus(AppConstants.StatusCodes.SUCCESS));
		baseApiResponse.setMessage("Success");
		return baseApiResponse;
	}
	
	public static BaseApiResponse getSuccessResponse() throws AppException {
		
		BaseApiResponse baseApiResponse = new BaseApiResponse();
		baseApiResponse.setStatusCode(AppConstants.StatusCodes.SUCCESS);
		//baseApiResponse.setResponseStatus(new ResponseStatus(AppConstants.StatusCodes.SUCCESS));
		baseApiResponse.setResponseData(null);
		baseApiResponse.setMessage("Success");
		return baseApiResponse;
	}

}
