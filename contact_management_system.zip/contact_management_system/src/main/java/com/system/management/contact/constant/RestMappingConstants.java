package com.system.management.contact.constant;

public interface RestMappingConstants {

	String APP_BASE = "/contact/v1";

	public interface TicketUri {

		String CREATE_USER = APP_BASE + "/createUser";
		String EDIT_USER = APP_BASE + "/editUser";
		String DELETE_USER = APP_BASE+ "/deleteUser";
		String VIEW_USER_BY_USER_ID = APP_BASE+ "/viewUserById";
		String USER_LIST = APP_BASE+ "/viewUserList";

		
	}

	
}
